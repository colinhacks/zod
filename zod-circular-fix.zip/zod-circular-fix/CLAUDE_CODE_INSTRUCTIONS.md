# Claude Code Instructions

## Task
Fix Zod issue #5346: Support circular object validation.

GitHub: https://github.com/colinhacks/zod/issues/5346

## Setup
```bash
git clone https://github.com/colinhacks/zod.git
cd zod
pnpm install
```

## Step 1: Add Failing Test
Copy `TEST_FIRST.ts` to the test directory:
```bash
cp TEST_FIRST.ts packages/zod/src/v4/classic/tests/circular.test.ts
```

Run it (should hang - use timeout):
```bash
pnpm vitest run packages/zod/src/v4/classic/tests/circular.test.ts --timeout=5000
```

## Step 2: Find the Parse Logic
The core parsing happens somewhere in `packages/zod/src/`. Look for:
- `_parse` or `parse` methods
- Object schema handling
- The recursion point where it processes nested objects

Key files to investigate:
- `packages/zod/src/v4/classic/` - main v4 implementation
- Look for `ZodObject` class or object parsing logic

## Step 3: Implement Fix
The fix needs to:

1. **Track visited objects** - Use a `WeakSet` (better than `Set` for objects - no memory leaks):
```typescript
// At the start of parsing
const visited = new WeakSet<object>();
```

2. **Check before recursing** - When about to parse an object:
```typescript
if (typeof value === 'object' && value !== null) {
  if (visited.has(value)) {
    // Already validated this exact object reference
    // Return success with the same reference
    return { success: true, data: value };
  }
  visited.add(value);
}
```

3. **Pass context through recursion** - The `visited` set needs to be passed through the parsing context so nested parsers can access it.

## Step 4: Run Tests
```bash
# Run just the circular test
pnpm vitest run packages/zod/src/v4/classic/tests/circular.test.ts

# Run full suite to check for regressions  
pnpm test

# Lint
pnpm fix
```

## Key Considerations

### WeakSet vs Set
Use `WeakSet` for the visited tracker:
- Only holds objects (not primitives) - perfect for this use case
- Doesn't prevent garbage collection
- O(1) lookup

### What "success" means for circular refs
When we encounter an already-visited object:
- We've already validated it on first encounter
- Return the same object reference (don't clone it)
- The circular structure is preserved in output

### Edge Cases to Handle
1. Self-reference: `obj.self = obj`
2. Mutual reference: `a.b = b; b.a = a`
3. Deep cycles: `a -> b -> c -> a`
4. Arrays with circular refs
5. Invalid data inside circular structure (should still fail validation)

## Success Criteria
- [ ] `pnpm vitest run packages/zod/src/v4/classic/tests/circular.test.ts` passes
- [ ] `pnpm test` passes (no regressions)
- [ ] `pnpm lint` passes

## Notes
- Zod v4 imports: `import { z } from "zod/v4"`
- Tests use Vitest
- All code must be TypeScript
- The maintainer (colinhacks) gave the issue a 👍 so this fix is wanted
