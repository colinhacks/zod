# Zod Circular Object Validation Fix

## Start Here
1. **Read `SCOPE.md`** - Full issue description, solution approach, and implementation steps
2. **Read `TEST_FIRST.ts`** - The failing test to implement first
3. **Read `CLAUDE_CODE_INSTRUCTIONS.md`** - Specific instructions for Claude Code

## Files
- `CONTENTS.md` - This file
- `SCOPE.md` - Complete scoping document with problem, solution, and repo info
- `TEST_FIRST.ts` - Failing test code to add to the repo
- `CLAUDE_CODE_INSTRUCTIONS.md` - Step-by-step for Claude Code

## Quick Start
```bash
# Clone zod
git clone https://github.com/colinhacks/zod.git
cd zod
pnpm install

# Add the test file
cp ../TEST_FIRST.ts packages/zod/src/v4/classic/tests/circular.test.ts

# Run test (should hang or fail)
pnpm vitest run packages/zod/src/v4/classic/tests/circular.test.ts --timeout=5000

# Now find the parse logic and add circular reference detection
```
