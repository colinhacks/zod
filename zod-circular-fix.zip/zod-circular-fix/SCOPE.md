# Zod Circular Object Validation - Claude Code Scope

## Issue Reference
**GitHub Issue:** https://github.com/colinhacks/zod/issues/5346
**Title:** Support circular object validation

## Problem Statement
Zod hangs infinitely when validating objects with circular references. Circular objects are valid JavaScript:

```javascript
const user = { 
  id: 1, 
  posts: [{ get author() { return user } }] 
}
// user.posts[0].author === user (circular reference)
```

Zod supports *declaring* such schemas via getters, but fails to *validate* them because it recurses infinitely.

## Proposed Solution (from issue)
Track visited nodes during parsing to detect and skip circular references:

```typescript
function parse() {
  const visitedNodes = new Set()
  
  function zodCrawler(value) {
    if (isObject(value)) {
      if (visitedNodes.has(value)) {
        return  // Already validated this exact object reference
      }
      visitedNodes.add(value)
      // ...continue with validation
    }
  }
  
  // Clear after validation completes
  visitedNodes.clear()
}
```

## Repository Setup

### Prerequisites
- Node.js v24+ (use nvm if needed)
- pnpm v10.12.1+

### Clone & Install
```bash
git clone https://github.com/colinhacks/zod.git
cd zod
pnpm install
```

### Key Commands (from AGENTS.md)
```bash
# Run specific test file
pnpm vitest run <path>
# Example: pnpm vitest run packages/zod/src/v4/classic/tests/string.test.ts

# Run specific test(s) within a file
pnpm vitest run <path> -t "<pattern>"

# Run all tests
pnpm test

# Watch mode
pnpm test:watch

# Coverage
pnpm vitest run --coverage

# Linting
pnpm lint
pnpm format
pnpm fix  # both
```

### Project Structure
```
packages/
└── zod/
    └── src/
        └── v4/
            └── classic/
                ├── tests/           # Test files go here
                │   ├── string.test.ts
                │   ├── object.test.ts
                │   └── ...
                └── ...              # Source files
```

## Implementation Steps

### 1. Write Failing Test First
Create or add to an existing test file (likely `object.test.ts` or create `circular.test.ts`):

```typescript
import { describe, expect, it } from "vitest";
import { z } from "zod/v4";

describe("circular object validation", () => {
  it("should not hang on circular references", () => {
    const UserSchema = z.object({
      id: z.number(),
      posts: z.array(z.lazy(() => PostSchema)),
    });

    const PostSchema = z.object({
      title: z.string(),
      author: z.lazy(() => UserSchema),
    });

    // Create circular object
    const user: any = { id: 1, posts: [] };
    const post = { title: "Hello", author: user };
    user.posts.push(post);

    // Should complete without hanging
    const result = UserSchema.safeParse(user);
    expect(result.success).toBe(true);
  });

  it("should validate circular self-reference", () => {
    const NodeSchema: z.ZodType<any> = z.object({
      value: z.number(),
      next: z.lazy(() => NodeSchema).optional(),
    });

    // Create self-referencing node
    const node: any = { value: 1 };
    node.next = node;  // Points to itself

    const result = NodeSchema.safeParse(node);
    expect(result.success).toBe(true);
  });
});
```

### 2. Run Test (Should Hang/Fail)
```bash
pnpm vitest run packages/zod/src/v4/classic/tests/circular.test.ts
```

### 3. Find the Parse Logic
Look for the core parsing/crawling logic - likely in:
- `packages/zod/src/v4/classic/` 
- Look for `parse`, `safeParse`, `_parse`, or similar methods
- The fix needs to add `Set` tracking for visited object references

### 4. Implement Fix
Add visited node tracking:
- Create a `Set` to track seen object references at parse start
- Check if object already visited before recursing
- Skip (return valid) if already seen
- Clear set after parse completes

### 5. Run Tests Until Green
```bash
pnpm vitest run packages/zod/src/v4/classic/tests/circular.test.ts
pnpm test  # Run full suite to ensure no regressions
```

### 6. Lint & Format
```bash
pnpm fix
```

## Notes

### ES Modules
- Entire codebase uses ES modules (`"type": "module"`)
- All tests must be TypeScript, never JavaScript

### Zod v4 Structure
- Zod 4 is at `zod/v4` subpath
- Import as: `import { z } from "zod/v4"`

### Test Patterns
Look at existing tests for patterns:
- Use `describe()` and `it()` from vitest
- Use `z.safeParse()` for non-throwing validation
- Check `result.success` and `result.data` or `result.error`

## Success Criteria
1. ✅ Test for circular objects passes
2. ✅ Test doesn't hang (add timeout if needed)
3. ✅ Full test suite still passes
4. ✅ Linting passes

## Maintainer Note
colinhacks (maintainer) gave the issue a 👍 - indicates openness to a PR.
